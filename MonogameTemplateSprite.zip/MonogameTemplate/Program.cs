﻿using var game = new MonogameTemplate_Sprite.Game1();
game.Run();
