﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace MonogameTemplate_Sprite;

public class Game1 : Game
{
    public SpriteBatch SpriteBatch;
    public GraphicsDeviceManager Graphics;
    public float DeltaTime;

    private AssetsLoader assetsLoader = new AssetsLoader();
    private GameLoop gameLoop = new GameLoop();

    public Game1()
    {
        this.Graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        this.TargetElapsedTime = TimeSpan.FromSeconds(1.0 / 60.0f);
        base.Initialize();

        this.Graphics.PreferredBackBufferWidth = 800;
        this.Graphics.PreferredBackBufferHeight = 600;
        this.Graphics.ApplyChanges();

        this.SpriteBatch = new SpriteBatch(this.GraphicsDevice);
        SpriteManager.Setup();

        gameLoop.Initalize(this);
    }

    protected override void LoadContent()
    {
        this.assetsLoader.Load(this.Content, this.GraphicsDevice);
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        this.DeltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;
        InputManager.Update();
        SpriteManager.Update(this.DeltaTime);
        gameLoop.Update(this.DeltaTime);
        
        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        this.GraphicsDevice.Clear(Color.Black);

        SpriteManager.Draw(this.SpriteBatch);    
        gameLoop.Draw(this.SpriteBatch);
        this.SpriteBatch.End();

        base.Draw(gameTime);
    }
}
