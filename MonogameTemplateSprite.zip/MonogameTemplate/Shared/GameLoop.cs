using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using MonogameTemplate_Sprite;

public class GameLoop {

    public void Initalize(Game1 game) {
        
    }

    public void Update(float deltaTime) {
        Console.WriteLine(InputManager.mouseState.LeftButton.ToString());   
    }

    public void Draw(SpriteBatch spriteBatch) {
        
    }

}