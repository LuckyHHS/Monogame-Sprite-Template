using System.Collections.Generic;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;


public static class Assets
{
    public static Dictionary<string, Texture2D> Images = new Dictionary<string, Texture2D>();
}

internal class AssetsLoader()
{
    public void Load(ContentManager contentMangager, GraphicsDevice graphicsDevice)
    {
        Assets.Images["Circle"] = contentMangager.Load<Texture2D>("Circle");
        Assets.Images["Square"] = contentMangager.Load<Texture2D>("Square");
    }
}
